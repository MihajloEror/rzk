package com.example.demo.exceptions;

public class BasicException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public BasicException(String poruka) {
		super(poruka);
	}
	
}
