package com.example.demo.controllersRest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.GlumacDTO;
import com.example.demo.exceptions.BasicException;
import com.example.demo.services.KolokvijumService;


@RestController
@RequestMapping("api/priprema/")
public class KolokvijumController {

	@Autowired
	KolokvijumService service;

	
	@GetMapping("getPredstave")
	public ResponseEntity<?> getPredstave(){
		return ResponseEntity.status(HttpStatus.OK).body(service.getPredstave());
	}
	
	
	@PostMapping("saveGlumac")
	public ResponseEntity<?> saveGlumac(GlumacDTO glumac){
		if (glumac.getIme().equals("Test")) {
			throw new BasicException("Greska");
		}
		return ResponseEntity.ok("Uspešno");
		
	}
	
	
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleNotFoundZException(RuntimeException e) {
		return ResponseEntity.badRequest().body("Greska: " + e.getMessage());
	}
}
