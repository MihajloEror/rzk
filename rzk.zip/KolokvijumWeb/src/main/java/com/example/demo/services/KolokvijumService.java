package com.example.demo.services;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.GlumacDTO;
import com.example.demo.dto.PredstavaDTO;
import com.example.demo.repositories.GlumacRepository;
import com.example.demo.repositories.PredstavaRepository;

import model.Glumac;
import model.Predstava;

@Service
public class KolokvijumService {

	@Autowired
	PredstavaRepository pr;
	
	@Autowired
	GlumacRepository gr;
	
	
	public List<PredstavaDTO> getPredstave(){
		List<Predstava> predstave = pr.findAll();
		List<PredstavaDTO> predstaveDTO = new LinkedList<>();
		for (Predstava p: predstave) {
			PredstavaDTO dto = new PredstavaDTO();
			BeanUtils.copyProperties(p, dto);
			predstaveDTO.add(dto);
		}
		return predstaveDTO;
	}
	
	public int saveGlumac(GlumacDTO glumac) {
		Glumac noviGlumac = new Glumac();
		noviGlumac.setIme(glumac.getIme());
		try {
			Glumac g = gr.save(noviGlumac);
			return g.getIdGlumac();
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}	
	}
}
